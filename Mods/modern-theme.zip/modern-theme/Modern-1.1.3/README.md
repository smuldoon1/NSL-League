# Winner of theme contest 2022 !!

# Modern
v1.1 support custom teams in standings and lineup you just need to activate the Not F1 Season Or Custom Teams

Know bugs :
Standings : width of first position is not right will be fixed in future
            Points will only match in standings when there 3 digits will be fixed when api is fixed need points to be int

![Capture](https://user-images.githubusercontent.com/880169/204158667-15483779-c2d1-4382-88a7-d197e84baca0.PNG)

# Installation
Download the last release on the right and save the zip file in your Racing League Tool Mods folder

Racingleaguetool/user/mods

Start Racing League Tool theme will be install set as default check options and enjoy !


Read the readme file before asking questions !!!!

# Flags
If you want to add round flags you need to download them here for free :https://www.freeflagicons.com/buy/round_icon/
Download 600px one and resize theme to 434px x 434px
Name them according to country database !


# Screenshots
Complete theme for Racing League Tool
![f1_season1_lineups](https://user-images.githubusercontent.com/880169/204111027-cf13870f-1bc0-4361-ba17-d7e3f940daaa.png)
![f1_season1_driver_standings1](https://user-images.githubusercontent.com/880169/204113371-1251fff3-0a7e-4b37-b4dd-0a9249265cae.png)
![f1_season1_team_standings1](https://user-images.githubusercontent.com/880169/204113372-a12ff46b-2d66-4b8d-aca3-139061b81d38.png)
![f1_season1_calendar](https://user-images.githubusercontent.com/880169/204111150-645f9c7f-d51b-43e6-a9c6-0320b37af650.png)
![unknown_render_type](https://user-images.githubusercontent.com/880169/204111029-6dfbf575-cdbd-40b3-a59f-ad909aad70e3.png)
![f1_season1_07_monaco_attack_rating_1](https://user-images.githubusercontent.com/880169/204111031-76799e00-4437-44da-9492-883952272451.png)
![f1_season1_07_monaco_constistancy_rating_1](https://user-images.githubusercontent.com/880169/204111032-2ac2c5da-1ae5-49e9-ba90-89fffc3e8b7a.png)
![f1_season1_07_monaco_defense_rating_1](https://user-images.githubusercontent.com/880169/204111033-65e0f867-2a95-46dc-b43e-f746dd0fb31f.png)
![f1_season1_07_monaco_longest_stints_1](https://user-images.githubusercontent.com/880169/204111034-34dc57f0-836f-45fe-9ba0-10ab99620c01.png)
![f1_season1_07_monaco_pure_race_pace_1](https://user-images.githubusercontent.com/880169/204111035-b59bdf2f-0f47-4869-b4e9-20ae7e5c988c.png)
![f1_season1_07_monaco_race_1](https://user-images.githubusercontent.com/880169/204111036-6526f272-7da6-4dc7-925c-cd8ebb0d5a07.png)
![f1_season1_07_monaco_top_battles_1](https://user-images.githubusercontent.com/880169/204111037-59f70063-ef47-4b94-b24e-84875190a91e.png)
![f1_season1_07_monaco_top_fastest_laps_1](https://user-images.githubusercontent.com/880169/204111038-2327fc00-963f-489d-8461-c0a44631b219.png)




